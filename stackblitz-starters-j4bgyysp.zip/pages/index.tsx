import Link from 'next/link';
import { signIn, signOut, useSession } from 'next-auth/react';

export default function Home() {
  const { data: session, status } = useSession();
  const loading = status === 'loading';

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-6">
      <h1 className="text-4xl font-bold mb-6 text-center">Spotify Session App</h1>

      {/* Spotify Login Section */}
      <div className="mb-8">
        {loading ? (
          <p>Loading...</p>
        ) : !session ? (
          <button
            onClick={() => signIn('spotify')}
            className="bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700"
          >
            Log in with Spotify
          </button>
        ) : (
          <div className="text-center">
            <p className="text-lg mb-2">Logged in as <strong>{session.user?.name}</strong></p>
            <button
              onClick={() => signOut()}
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
            >
              Log out
            </button>
          </div>
        )}
      </div>

      {/* Navigation Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Link href="/start">
          <button className="bg-blue-600 text-white px-6 py-3 rounded hover:bg-blue-700 w-52">
            Start a Session
          </button>
        </Link>
        <Link href="/join">
          <button className="bg-purple-600 text-white px-6 py-3 rounded hover:bg-purple-700 w-52">
            Join a Session
          </button>
        </Link>
      </div>
    </main>
  );
}
