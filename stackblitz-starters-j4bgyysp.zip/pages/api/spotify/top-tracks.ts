// pages/mytracks.tsx
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

type Track = {
  id: string;
  name: string;
  artists: { name: string }[];
  album: { name: string; images: { url: string }[] };
  external_urls: { spotify: string };
};

export default function MyTracks() {
  const { data: session, status } = useSession();
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTracks = async () => {
      const res = await fetch('/api/spotify/top-tracks');
      const data = await res.json();
      setTracks(data.items || []);
      setLoading(false);
    };

    if (status === 'authenticated') {
      fetchTracks();
    }
  }, [status]);

  if (status === 'loading' || loading) {
    return <p className="p-4">Loading your top tracks...</p>;
  }

  if (!session) {
    return <p className="p-4">Please log in to view your top tracks.</p>;
  }

  return (
    <main className="min-h-screen bg-white p-6">
      <h1 className="text-3xl font-bold mb-6">Your Top 50 Spotify Tracks (All Time)</h1>
      <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {tracks.map((track, index) => (
          <li key={track.id} className="bg-gray-100 p-4 rounded shadow">
            <div className="flex items-center gap-4">
              <img
                src={track.album.images[0]?.url}
                alt={track.name}
                className="w-16 h-16 rounded"
              />
              <div>
                <p className="font-semibold">{index + 1}. {track.name}</p>
                <p className="text-sm text-gray-600">
                  {track.artists.map((a) => a.name).join(', ')}
                </p>
                <a
                  href={track.external_urls.spotify}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 text-sm underline"
                >
                  Open in Spotify
                </a>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
