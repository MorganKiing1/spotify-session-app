import { useRouter } from 'next/router';

export default function SessionPage() {
  const router = useRouter();
  const { id } = router.query; // grabs session ID from the URL

  return (
    <main className="min-h-screen bg-white p-4">
      <h1 className="text-3xl font-bold mb-4">Session Dashboard</h1>
      <p className="text-lg">You're viewing session ID: <strong>{id}</strong></p>

      <div className="mt-6">
        <p>✅ This is where you'll see:</p>
        <ul className="list-disc ml-6">
          <li>Combined Top 50 Tracks</li>
          <li>List of Joined Users</li>
          <li>Each User’s Top Tracks</li>
          <li>Buttons to Remove Users / End Session</li>
        </ul>
      </div>
    </main>
  );
}
